<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
<form method="POST" >
	<label>Valor:</label>
	<input type="text"  name="numero"/><br/>
	<span>Primeiro:</span>
	<select name="primeiro">
		<option selected></option>
		<option value="Real">Real</option>
		<option value="Dolar">Dólar</option>
		<option value="Euro">Euro</option>
	</select><br/>
	<span>Para</span><br/>
	<span>Segundo:</span>
	<select name="segundo">
	<option selected></option>
		<option value="Real">Real</option>
		<option value="Dolar">Dólar</option>
		<option value="Euro">Euro</option>
	</select><br/>
	
	<input type="submit" name="" value="Converte">
	</form>
</body>
</html>
 <?php
 $numero = isset($_POST['numero'])?$_POST['numero']:"Preechar esse campo";
$primeiro = isset($_POST["primeiro"])?$_POST["primeiro"]:"nao existe";
$segundo = isset($_POST["segundo"])?$_POST["segundo"]:"nao existe";
switch ($primeiro) {
	case "Dolar":
	switch ($segundo) {
		case "Real":
				dolar($numero);
			break;
	}
		break;
	case "Real":
		switch ($segundo) {
			case "Dolar":
			real($numero);
				break;
			case "Euro":
				euro($numero);
					break;
			}
	break;
	case "Euro":
	switch ($segundo) {
		case "Real":
			convert_euro_para_real($numero);
			break;
	}
		break;
}

function real($num)
	{
	$open = "https://pt.exchange-rates.org/";
	$parse_url = file_get_contents($open);
	$table = explode('td class="cross-rate">', $parse_url);
	$valor = explode("<br>", $table[2]);
	$com_virgura_numero = str_replace(",",".",$num);
	$com_virgura_dolar =str_replace(",", ".", $valor[0]);
	$calculo_dolar = $com_virgura_dolar* $com_virgura_numero;
	echo "U$ ".str_replace(".",",",$calculo_dolar);
	}
function  dolar($num){
	$open = "https://pt.exchange-rates.org/";
	$parse_url = file_get_contents($open);
	$table = explode('<td class="cross-rate">', $parse_url);
	$valor = explode("<br>", $table[15]);
	$com_virgura_numero = str_replace(",",".",$num);
	$com_virgura_dolar =str_replace(",", ".", $valor[0]);
	$calculo_real = $com_virgura_dolar * $com_virgura_numero;
	echo "R$ ".str_replace(".",",",$calculo_real);
}
function euro($num){
	$open = "https://pt.exchange-rates.org/";
	$parse_url = file_get_contents($open);
	$table = explode('td class="cross-rate">', $parse_url);
	$valor = explode("<br>", $table[1]);
	$com_virgura_numero = str_replace(",",".",$num);
	$euro =str_replace(",", ".", $valor[0]);
	$calculo_euro = $euro * $com_virgura_numero;
	echo "€ ".str_replace(".",",",$calculo_euro);
}
function convert_euro_para_real($num){

	$open = "https://pt.exchange-rates.org/";
	$parse_url = file_get_contents($open);
	$table = explode('<td class="cross-rate">', $parse_url);
	$valor = explode("<br>", $table[8]);
	$com_virgura_numero = str_replace(",",".",$num);
	$euro_virgura =str_replace(",", ".",$valor[0]);
	$euro_real = $euro_virgura * $com_virgura_numero;
	echo  "R$ ".str_replace(",", ".",$euro_real);
}

				 ?>